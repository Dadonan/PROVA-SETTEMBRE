/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.esorariodocenti;

/**
 *
 * @author Nanni_Davide
 */
public class ThCercaClasse extends Thread {
    private DatiCondivisi dc;

    public ThCercaClasse(DatiCondivisi dc) {
        this.dc = dc;
    }
    
    public void run(){
        //cerca dentro l'orario la classe
        int giorno =0;
        boolean trovato=false;
        for(int i=0,i<vett.lenght(),i++)
        {
            if(classe ==i)
                trovato = true;
        if(trovato=true)
            i.getpos();
        while(i.getpos>6)
        {
            i.getPos-=6
            giorno++;
        }
        if(giorno==0)
            dc.getOrarioSettimanale()+="LUN"
            dc.getOrarioSettimanale()+=","
            dc.getOrarioSettimanale()+=i.getPos
        if(giorno==1)
            dc.getOrarioSettimanale()+="MAR"
            dc.getOrarioSettimanale()+=","
            dc.getOrarioSettimanale()+=i.getPos
        if(giorno==2)
            dc.getOrarioSettimanale()+="MER"
            dc.getOrarioSettimanale()+=","
            dc.getOrarioSettimanale()+=i.getPos        
        if(giorno==3)
            dc.getOrarioSettimanale()+="GIO"
            dc.getOrarioSettimanale()+=","
            dc.getOrarioSettimanale()+=i.getPos       
        if(giorno==4)
            dc.getOrarioSettimanale()+="VEN"
            dc.getOrarioSettimanale()+=","
            dc.getOrarioSettimanale()+=i.getPos        
        if(giorno==5)
            dc.getOrarioSettimanale()+="SAB"ù
            dc.getOrarioSettimanale()+=","
            dc.getOrarioSettimanale()+=i.getPos
         
                    
            }  
    
   }
}
